LIBAS BY AFI — STARTER WEBSITE
================================

WHAT THIS IS
A mobile-friendly storefront prototype for listing clothing products, adding them to a cart, and previewing an admin product manager.

IMPORTANT LIMITATIONS
- This is a front-end demo, NOT a production-ready ecommerce store.
- Product data is saved only in the current browser using localStorage. It will not sync to other devices or browsers.
- The owner login in index.html is demo-only and is NOT secure. Change ADMIN_USER and ADMIN_PASS for a private local demo, but do not publish this as a real secure admin login.
- Checkout intentionally does NOT take payment or create a real order. It only validates the shipping address is in Himachal Pradesh and explains that payment/backend setup is needed.
- Do not collect real customer details until a secure backend and privacy policy are added.
- Real prepaid UPI/cards/net banking requires a payment gateway account, verification, and usually transaction fees. All-India/Himachal shipping requires a courier arrangement. COD is not enabled.
- Sample products and prices are placeholders. Replace with your real stock, correct product descriptions and your own product photos before publishing.
- Do not call an invented compare-at price an official printed MRP. Use only a genuine declared MRP where applicable.

HOW TO OPEN
1. Extract libas-by-afi-website.zip.
2. Open index.html in a web browser.
3. Tap Owner Login.
   Demo username: afi
   Demo password: change-this-password
4. Add products from the admin panel. Data stays in that browser only.

HOW TO PUBLISH A FREE STATIC PREVIEW
You can publish the static preview using a free static hosting provider such as GitHub Pages. Create a repository, upload index.html, enable Pages in repository settings, and use the assigned subdomain. Hosting a static preview does not make admin login or payments secure.
